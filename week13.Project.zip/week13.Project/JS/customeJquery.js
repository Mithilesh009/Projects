$(document).ready(function () {
    //jQuery function for creating accordian
    $('.accordian').click(function () {

        //toggle indicator from + to - & from - to +
        $(this).closest('.accordian').find('.indicator').text($(this).find('.indicator').text() == '+' ? '-' : '+');
        $(this).find('.content').toggle(300);

    });
    //function to go to top of page
    $('#goTop').click(function () {
        window.location.href = '#nav1';
    });
    //quantity input in product view page
    var n = 1;
    //decreasing value
        $('.quantity div:nth-child(1)').click(function(){
            if(n>1){
                n--;
                $(this).closest('.quantity').find('.val').find('strong').text(n);
            }
        });
    //increasing value
        $('.quantity div:nth-child(3)').click(function(){
            n++;
            $(this).closest('.quantity').find('.val').find('strong').text(n);
        });
    //on click side nav toggle button, make side nav bar div visible by positioning it to left at 0%
    $('#sideToggleBtn').click(function(){
        $('#sideBarDiv').css("left","0%");
    });
    $('#sideToggleCrossBtn').click(function(){
        $('#sideBarDiv').css("left","-200%");
    });
});
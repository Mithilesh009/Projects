//function to change contact details and flag to hindi
function hindi() {
    document.getElementById('activeLanguage').innerHTML = ' Hindi ';
    var flag = document.getElementById('flag');
    flag.src = "img/india.png";
    document.getElementById('contactNo').innerHTML = '+91 9838203700';
}
//function to change contact details and flag to english
function english() {
    document.getElementById('activeLanguage').innerHTML = ' English ';
    var flag = document.getElementById('flag');
    flag.src = "img/Group 2560.png";
    document.getElementById('contactNo').innerHTML = '+1 3045670514';
}
//function to change contact details and flag to german
function german() {
    document.getElementById('activeLanguage').innerHTML = ' German ';
    var flag = document.getElementById('flag');
    flag.src = "img/german.png";
    document.getElementById('contactNo').innerHTML = '+49 301234567';
}

//function for clickable star buttons
function stars(num) {
    for (let i = 1; i <= num; i++) {
        var x = 'star' + i;
        var s = document.getElementById(x);
        s.src = 'img/Path 9645.png';
    }
    for (let j = 5; j > num; j--) {
        var x = 'star' + j;
        var s = document.getElementById(x);
        s.src = 'img/Path -5.png';
    }
    var rating = '  ' + num + ' out of 5 stars'
    document.getElementById('rating').innerHTML = rating;
}
//function to go to product review section in 0.3sec.
function goToReview() {
    let tID = setTimeout(function () {
        window.location = '#review';
        window.clearTimeout(tID);
    }, 300);

}
//product view image galary buttons
function changeProductImg(val) {
    var product = document.getElementById('productImg');
    product.src = val;

}
//getting go to top button 
var goTop = document.getElementById('goTop');
//getting position of scrolling
window.onscroll = function () {
    scrollFunction()
};
//checking for position of scrolling
function scrollFunction() {
    if (document.body > 300 || document.documentElement.scrollTop > 300) {
        //making go to top button visible
        goTop.style.transform = "scale(1)";
        goTop.style.transitionDuration = "0.5s";
        goTop.style.animation = "ease-in-out";
        goTop.style.top = "80%";
    } else {
        //dissapearing go to top button
        goTop.style.transform = "scale(0)";
        goTop.style.top = "100%";
    }
}
//Sending async request for JSON file and fetch data
async function loadProduct() {
    const response = await fetch('JS/productData.json');
    const listOfProducts = await response.json();
    return listOfProducts;
}

//after DOM loading checking for error  and then printing data
let listOfProducts = [];
document.addEventListener("DOMContentLoaded", async () => {
    try {
        listOfProducts = await loadProduct();
    } catch (e) {
        console.log("error");
        console.log(e);
    }
    document.querySelectorAll(".totalProduct").forEach(total => total.innerHTML = `(${listOfProducts.length} items)`);
    //to print products in div with class name .listOfProducts
    document.querySelectorAll(".listOfProducts").forEach(P => P.innerHTML = `
         <div class="row">
         ${listOfProducts.map(productDisplay).join("")}
         </div>
     `);

    //after all data get fetched, executing hover effect and display rating stars
    $(document).ready(function () {
        $('.favBtn').hover(function () {
            $(this).attr("src", "img/Group 2582.png");
        }, function () {
            $(this).attr("src", "img/Group 2579.png");
        });
        //changing image source of watchlist hover button oh hover
        $('.watchBtn').hover(function () {
            $(this).attr("src", "img/Group 2583.png");
        }, function () {
            $(this).attr("src", "img/Group 2580.png");
        });

        //changing image source of cart hover button oh hover
        $('.cartBtn').hover(function () {
            $(this).attr("src", "img/Group 2584.png");
        }, function () {
            $(this).attr("src", "img/Group 2581.png");
        });

        //prepend image to show star icons in displaystar span according to the last no. in class name
        $('[class^="displayStar"]').prepend(function () {
            //taking the last no. of displayStar class & convert to num
            var c = $(this).attr("class");
            var num = parseInt(c.charAt(11));
            var x = '';
            //getting dark stars
            for (let i = 0; i < num; i++) {
                x = x + '<img src="img/Path 9645.png" height="22px">';
            }
            //getting ligt stars at the end 
            for (let i = 0; i < 5 - num; i++) {
                x = x + '<img src="img/Path -5.png" height="22px">';
            }
            return x;
        });
        CartCalculation();
    });
    //declaring item array
    cart = [];
    $('.cartBtn').click(function () {
        //cheaking for local storage
        if (typeof (Storage) != 'undefined') {
            //getting all of the product information to be saved in local storage
            let item = {
                ID: $(this).closest('.product').attr('id'),
                quantity: 1
            };
            //saving cart when Local storage is empty
            if (JSON.parse(localStorage.getItem('cart')) === null) {
                cart.push(item);
                localStorage.setItem("cart", JSON.stringify(cart));
                window.location.reload();
            } else {
                //getting previous data of local storage
                const localItems = JSON.parse(localStorage.getItem("cart"));
                localItems.map(data => {
                    if (item.ID == data.ID) {
                        //if same item is clicked twice it increases quantity
                        item.quantity = data.quantity + 1;
                    } else {
                        //else push in cart
                        cart.push(data);
                    }
                });
                //pushing all item in items array and saving in local storage
                cart.push(item);
                localStorage.setItem('cart', JSON.stringify(cart));
                window.location.reload();
            }
            alert("!!! Product Added Successfully to Cart !!!");
        } else {
            //in case of no storage
            alert("No storage");
        }
    });
    //declaring item array
    wishlist = [];
    $('.favBtn').click(function () {
        //cheaking for local storage
        if (typeof (Storage) != 'undefined') {
            //getting all of the product information to be saved in local storage
            let item = {
                ID: $(this).closest('.product').attr('id')
            };
            //saving cart when Local storage is empty
            if (JSON.parse(localStorage.getItem('wishlist')) === null) {
                wishlist.push(item);
                localStorage.setItem("wishlist", JSON.stringify(wishlist));
                window.location.reload();
            } else {
                //getting previous data of local storage
                const localItems = JSON.parse(localStorage.getItem("wishlist"));
                localItems.map(data => {
                    if (item.ID != data.ID) {
                        //if same item is clicked twice it increases quantity
                        wishlist.push(data);
                    }
                });
                //pushing all item in items array and saving in local storage
                wishlist.push(item);
                localStorage.setItem('wishlist', JSON.stringify(wishlist));
                window.location.reload();
            }
            alert("!!! Product Added Successfully to Wishlist !!!");
        } else {
            //in case of no storage
            alert("No storage");
        }
    });
    //getting wishlist from local storage
    let wishlistItems = JSON.parse(localStorage.getItem('wishlist'));
    //checking for not null
    if (wishlistItems != null) {
        //try & catch is used so that it do not cause errors in other pages which dont have the ID of which css has been changed
        try {
            //getting the div with id wishlistProduct & making it empty
            document.getElementById("wishlistProduct").innerHTML = ``;
            //mapping all wishlist items
            wishlistItems.map(item => {
                listOfProducts.map(product => {
                    //matching wishlist product id with list of product id
                    if (item.ID == product.ID) {
                        //appending the div with id wishlistProduct with wishlist product cards from wishlistDisplay function
                        document.getElementById("wishlistProduct").innerHTML += wishlistDisplay(product);
                    }
                });
            });
            totalWishlist();
        } catch (error) {
            //blank
        }

    }
    //getting cart from local storage
    let cartItems = JSON.parse(localStorage.getItem('cart'));
    //checking for not null
    if (cartItems != null) {
        //try & catch is used so that it do not cause errors in other pages which dont have the ID of which css has been changed
        try {
            //getting the div with id cartProduct & making it empty
            document.getElementById("cartProduct").innerHTML = ``;
            //mapping all cart items
            cartItems.map(item => {
                listOfProducts.map(product => {
                    //matching cart product id with list of product id
                    if (item.ID == product.ID) {
                        //appending the div with id cartProduct with cart product cards from cartDisplay function
                        document.getElementById("cartProduct").innerHTML += cartDisplay(product, item);
                    }
                });
            });
        } catch (error) {
            //blank
        }
    }
    //getting orders from local storage
    let orders = JSON.parse(localStorage.getItem('orders'));
    //checking for not null
    if (orders != null) {
        //try & catch is used so that it do not cause errors in other pages which dont have the ID of which css has been changed
        try {
            //getting the div with id orderedProduct & making it empty
            document.getElementById("orderedProduct").innerHTML = ``;
            //mapping all order items
            orders.map(item => {
                listOfProducts.map(product => {
                    //matching order product id with list of product id
                    if (item.ID == product.ID) {
                        //appending the div with id orderedProduct with order product cards from ordersDisplay function
                        document.getElementById("orderedProduct").innerHTML += ordersDisplay(product);
                    }
                });
            });
        } catch (error) {
            //blank
        }
    }
    //getting track Order ID from local storage
    let trackOrderID = localStorage.getItem('trackOrderID');
    //checking for not null
    if (trackOrderID != null) {
        //try & catch is used so that it do not cause errors in other pages which dont have the ID of which css has been changed
        try {
            //getting the div with id TrackProductDetail & making it empty
            document.getElementById("TrackProductDetail").innerHTML = ``;
            //mapping all products and checking for trackOrderID
                listOfProducts.map(product => {
                    if (trackOrderID == product.ID) {
                        //appending the div with id TrackProductDetail with track product details from trackDetailDisplay function
                        document.getElementById("TrackProductDetail").innerHTML += trackDetailDisplay(product);  
                    }
                });
        } catch (error) {
            //blank
        }
    }

});
//functing returning trackOrderDetail product information
function trackDetailDisplay(product){
    return`
    <div class="row mt-3" id="trackOrder">
        <div class="col-12 col-lg-7">
            <div class="row">
                <div class="col-12 col-md-3 py-2 text-center">
                    <img id="trackOrderImg" src="${product.image}" class="img-fluid border" alt="product image">
                </div>
                <div class="col-12 col-md-9 ps-3">
                    <strong class="fs-5">${product.name}</strong><br>
                    <span class="displayStar${product.rating}"></span> &nbsp;<p class="type1">(2345)</p><br>
                <p class="type1">Colour : Multicolour</p><br>
                <p class="type1">Sold By : Krishnapoojabhandar</p><br>
                <strong>Rs. <p class="d-inline">${product.discountPrice}</p> </strong>
                <span class="text-decoration-line-through "> Rs. <p class="d-inline">${product.price}</p></span>
                <strong class="type2">(${Math.floor((product.price - product.discountPrice) / product.price * 100)}% Off)</strong><br>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-5">
            <strong >Delivary expected by Wed, July 22, 2022</strong><br>
            <button><img src="img/cancel.png" alt="cancel"> Cancel Item</button>
            <button class="float-end"><img src="img/help.png" alt="help"> Need Help?</button>
        </div>
    </div>
    `;
}
//functing returning order product card
function ordersDisplay(product) {
    return `
    <div class="card orderCard" id="${product.ID}">
        <div class="row">
            <div class="col-12 col-sm-3 col-md-2 col-lg-2 text-center">
                <img src="${product.image}" alt="product image" class="img-fluid mb-2 border">
            </div>
            <div class="col-12 col-sm-6 col-md-6 col-lg-4 ps-4">
                <strong>${product.name}</strong><br>
                <p class="type1">Colour : Multicolour</p><br>
                <p class="type1">Seller : Krishnapoojabhandar</p>
            </div>
            <div class="col-12 col-sm-3 col-md-3 col-lg-2 ps-4">
                <strong class="float-sm-end float-lg-none ">Rs. ${product.discountPrice}</strong>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-4 ps-4">
                <strong><img src="img/Ellipse 30.png" alt="circle"> Delivery expected by July
                    28</strong><br>
                <p class="type1">Your order has been placed</p><br>
                <button onclick=trackOrderDetail(${product.ID})>TRACK YOUR ORDER</button>
            </div>
        </div>
    </div>
    `;
}
//functing returning wishlist product card
function wishlistDisplay(product) {
    return `
    <div class="wishlist card" id="${product.ID}">
        <div class="row py-4">
            <div class="col-12 col-md-3 py-2 text-center">
                <img src="${product.image}" class="img-fluid border" alt="product image">
            </div>
            <div class="col-12 col-md-9 ps-5">
                <strong class="fs-4">${product.name}</strong><br>
                <span class="displayStar${product.rating}"></span> &nbsp;<p class="type1">(2345)</p><br>
                <strong>Rs. <p class="d-inline">${product.discountPrice}</p> </strong>
                <span class="text-decoration-line-through "> Rs. <p class="d-inline">${product.price}</p></span>
                <strong class="type2">(${Math.floor((product.price - product.discountPrice) / product.price * 100)}% Off)</strong><br>
                <select class="form-select" aria-label="Size">
                    <option selected disabled>Select Pack of</option>
                    <option value="1">Pack of 1</option>
                    <option value="2">Pack of 2</option>
                    <option value="3">Pack of 3</option>
                </select>
                <span class="mb-3">
                    <button class="addToCart" onclick=wishlistToCart(${product.ID})>Add to Cart</button>
                    <p class="type1">|</p>
                    <button class="remove" onclick=removeFromWishlist(${product.ID})>Remove from Wishlist</button>
                </span>
            </div>
        </div>
    </div>
    `;
}
//functing returning product card in product listing
function productDisplay(product) {
    return `
            <div class="col-12 col-md-6 col-lg-6 col-xl-4 ">
            <!-- card containing product -->
            <div class="product card text-center" id="${product.ID}">
                <div class="fade">
                    <img src="${product.image}" alt="product" class="img-fluid">
                    <div class="mt-2">
                        <strong>${product.name}</strong><br>
                        <strong>Rs. <p class="d-inline">${product.discountPrice}</p> </strong>
                        <span class="text-decoration-line-through "> Rs. <p class="d-inline">${product.price}</p></span>
                        <strong class="type2"> (${Math.floor((product.price - product.discountPrice) / product.price * 100)}% Off)</strong><br>
                        <!-- displaystar span generates star icon through jQuery based on number -->
                        <span class="displayStar${product.rating}"></span>
                    </div>
                </div>
                <!-- checking if newTag image is required or not -->
                ${product.new ? `<img class="newTag" src="img/Group 2562.png" alt="new">` : ``}
                <!-- hover btn on hovering changes image src -->
                <span class="hoverBtn">
                    <button class="btn"><img class="favBtn" src="img/Group 2579.png" alt="favorite"></button>
                    <button class="btn"><img class="watchBtn" src="img/Group 2580.png" alt="watchlist"></button>
                    <button class="btn"><img class="cartBtn" src="img/Group 2581.png" alt="cart"></button>
                </span>
            </div>
            </div>
            `;
}
//functing returning cart product card
function cartDisplay(product, item) {
    //card containing table of row and col class 
    //column 1 containing product image
    //column 2 containing product discription and quantity selector
    //column 3 containing price detail
    //bottom of card containing remove button & add to wishlist button
    return `
        <div class="cartProduct card" id="${product.ID}">
                    <div class="row container-fluid my-3">
                        <div class="col-12 col-md-2 text-center">
                            <img src="${product.image}" class="img-fluid border" alt="product image">
                        </div>
                        <div class="col-12 col-md-7 mb-3">
                            <strong>${product.name}</strong><br>
                            <p class="type1">Colour : White</p><br>
                            <p class="type1">Sold By : Macmerise Celfie Design Private Limited</p>
                            <div class="row selector">
                                <div class="col-10 col-sm-8 col-xl-6 col-xxl-4 mt-2">
                                    <select class="form-select" aria-label="Size">
                                        <option selected disabled>Size : Onesize</option>
                                        <option value="Twosize">Size : Twosize</option>
                                        <option value="Threesize">Size : Threesize</option>
                                    </select>
                                </div>
                                <div class="col-6 col-sm-4 col-xl-4 col-xxl-3 mt-2">
                                    <select class="form-select QTY" aria-label="Quantity" onchange="QTYchange(this.selectedIndex,${product.ID})">
                                        <option selected disabled value="">QTY : ${item.quantity}</option>
                                        <option value ="1" >QTY : 1</option>
                                        <option value="2">QTY : 2</option>
                                        <option value="3">QTY : 3</option>
                                        <option value="4">QTY : 4</option>
                                        <option value="5">QTY : 5</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-3">
                            <strong>Rs. <p class="d-inline">${product.discountPrice}</p> </strong><br>
                        <span class="text-decoration-line-through "> Rs. <p class="d-inline">${product.price}</p></span>
                        <strong class="type2 d-inline fs-6"> (${Math.floor((product.price - product.discountPrice) / product.price * 100)}% Off)</strong>
                        <p>Delivery in 4-6 days</p>
                        </div>
                    </div>
                    <hr>
                    <span class="mb-3">
                        <button class="remove" onclick=removeFromCart(${product.ID})>Remove</button><p class="type1">|</p>
                    <button onclick=cartToWishlist(${product.ID})>Move to Wishlist</button>
                    </span> 
                </div>
        `;
}
//function takes paramener of product and save the id in local Storage and open track Order Detail page
function trackOrderDetail(product){
    localStorage.setItem('trackOrderID',product.id);
    location.href = "trackOrderDetails.html";
}
//removeFromCart function called on clicking remove button
//it takes parameter of clicked product 
function removeFromCart(e) {
    //declaring items array
    let items = [];
    //finding the required product to be removed by maping local storage data
    JSON.parse(localStorage.getItem('cart')).map(data => {
        if (data.ID != e.id) {
            //pushing all unmatched data
            items.push(data);
        }
    });
    //saving in local storage
    localStorage.setItem("cart", JSON.stringify(items));
    //fade the card div of product in 0.3s
    $("#" + e.id).fadeOut(300);
    //calling calculation function to change bill values
    CartCalculation();
}
//removeFromWishlist function called on clicking remove button
//it takes parameter of clicked product 
function removeFromWishlist(e) {
    //declaring items array
    let items = [];
    //finding the required product to be removed by maping local storage data
    JSON.parse(localStorage.getItem('wishlist')).map(data => {
        if (data.ID != e.id) {
            //pushing all unmatched data
            items.push(data);
        }
    });
    //saving in local storage
    localStorage.setItem("wishlist", JSON.stringify(items));
    //fade the card div of product in 0.3s
    $("#" + e.id).fadeOut(300);
    //calling calculation function to change total item count
    totalWishlist();
}
//function pushes wishlist product in localStorage to cart and delete from wishlist
function wishlistToCart(e) {
    //declaring items array
    let items = [];
    JSON.parse(localStorage.getItem('cart')).map(data => {
        //pushing all previous cart data in items
        items.push(data);
    });
    //declaring an item which needed to be added
    let item = {
        ID: e.id,
        quantity: 1
    };
    //pushng that item
    items.push(item);
    //saving in local storage
    localStorage.setItem("cart", JSON.stringify(items));
    //deleting & fade the card div of product in 0.3s
    removeFromWishlist(e);
    //calling calculation function to change total wishlist count
    totalWishlist();
}
//function pushes cart product in localStorage to wishlist and delete from cart
function cartToWishlist(e) {
    //declaring items array
    let items = [];
    JSON.parse(localStorage.getItem('wishlist')).map(data => {
        //pushing all previous wishlist data in items
        items.push(data);
    });
    //declaring an item which needed to be added
    let item = {
        ID: e.id
    };
    //pushng that item
    items.push(item);
    //saving in local storage
    localStorage.setItem("wishlist", JSON.stringify(items));
    //deleting & fade the card div of product in 0.3s
    removeFromCart(e);
    //calling calculation function to change bill values   
    CartCalculation();
}
//QTYchange function called on selecting quantity in cart product card
//it takes parameter of clicked product & quantity
function QTYchange(QTY, e) {
    //declaring items array
    let items = [];
    //finding the required product to change quantity by maping local storage data
    JSON.parse(localStorage.getItem('cart')).map(data => {
        if (data.ID == e.id) {
            //changing and pushing data in items array
            data.quantity = parseInt(QTY);
            items.push(data);
        } else {
            //pushing data in items array
            items.push(data);
        }
    });
    //saving changed value in local storage
    localStorage.setItem("cart", JSON.stringify(items));
    //calling calculation function to change bill values
    CartCalculation();

}
//function to print the total number of wishlist items
function totalWishlist() {
    document.getElementById('totalWishlist').innerHTML = JSON.parse(localStorage.getItem('wishlist')).length;
}
//calculation function changes all billing values 
function CartCalculation() {
    //declaring integer for total cost & gross cost
    var grossPrice = 0,
        totalCost = 0;
    if (JSON.parse(localStorage.getItem('cart')) != null) {
        JSON.parse(localStorage.getItem('cart')).map(item => {
            listOfProducts.map(product => {
                if (item.ID == product.ID) {
                    totalCost += parseInt(product.discountPrice) * item.quantity;
                    grossPrice += parseInt(product.price) * item.quantity;
                }
            });
        });
        //changing total cost element innerHTML
        document.querySelectorAll(".totalCost").forEach(total => total.innerHTML = totalCost);
        //changing gross cost element innerHTML
        document.querySelectorAll(".grossPrice").forEach(total => total.innerHTML = grossPrice);
        //changing discounted cost element innerHTML
        document.querySelectorAll(".totalDiscount").forEach(total => total.innerHTML = (grossPrice - totalCost));
    }
    //change value in div with class cartLength to get total items
    document.querySelectorAll(".cartLength").forEach(total => total.innerHTML = `${JSON.parse(localStorage.getItem('cart')).length} `);
}
//on click of submit button in #editProfile form, function saves all the values in local storage
$('#editProfile > input[type = "submit"]').click(function () {
    //declaring profile array which will contain all profile info
    let profile = [];
    //function either return user input gender or templet of "- not added -" strong text if input by user not provided
    function findGender(gender) {
        let g = document.getElementsByName(gender);
        if (g[0].checked) {
            return "Male";
        } else if (g[1].checked) {
            return "Female";
        } else {
            return `<strong class="type1">- not added -</strong>`;
        }
    }
    //function either return user input value or templet of "- not added -" strong text if input by user not provided
    function findValue(id) {
        if (document.getElementById(id).value != "") {
            return document.getElementById(id).value;
        } else {
            return `<strong class="type1">- not added -</strong>`;
        }
    }
    //data will contain all profile info
    let data = {
        NAME: findValue('name'),
        email: findValue('email'),
        mobile: findValue('mobile'),
        DOB: findValue('DOB'),
        location: findValue('location'),
        alternateMobile: findValue('alternateMobile'),
        nickname: findValue('nickname'),
        gender: findGender('gender')
    };
    //pushing data in profile
    profile.push(data);
    //saving profile in local storage
    localStorage.setItem("profile", JSON.stringify(profile));
    //reloading page
    window.location.reload();
});
//checking if profile is empty or not
if (JSON.parse(localStorage.getItem("profile")) != null) {
    //mapping aal profile data
    JSON.parse(localStorage.getItem("profile")).map(p => {
        //changing innerHTML of required elements through name
        document.getElementsByName("P_Mobile").forEach(e => e.innerHTML = p.mobile);
        document.getElementsByName("P_Name").forEach(e => e.innerHTML = p.NAME);
        document.getElementsByName("P_Email").forEach(e => e.innerHTML = p.email);
        document.getElementsByName("P_Gender").forEach(e => e.innerHTML = p.gender);
        document.getElementsByName("P_DOB").forEach(e => e.innerHTML = p.DOB);
        document.getElementsByName("P_Location").forEach(e => e.innerHTML = p.location);
        document.getElementsByName("P_Alternate").forEach(e => e.innerHTML = p.alternateMobile);
        document.getElementsByName("P_Nickname").forEach(e => e.innerHTML = p.nickname);
    });
    //try & catch is used so that it do not cause errors in other pages which dont have the ID of which css has been changed
    try {
        //making profile edit form not vissible when profile data has already saved
        document.getElementById("editProfile").style.display = "none";
        //making profile info table vissible when profile 
        document.getElementById("profile").style.display = "block";
        //changing heading of page
        document.getElementById("P_heading").innerHTML = "PROFILE";
    } catch (error) {
        //blank
    }
} else {
    //making profile edit form vissible when profile data has not taken by user
    document.getElementById("editProfile").style.display = "block";
    //making profile info table not vissible when profile data not taken by user
    document.getElementById("profile").style.display = "none";    
    //changing heading of page
    document.getElementById("P_heading").innerHTML = "EDIT PROFILE";
}
//function called on click of edit profile button 
function editProfile() {
    //making edit profile foem visible
    document.getElementById("editProfile").style.display = "block";
    //making profile info not visible
    document.getElementById("profile").style.display = "none";
    //changing heading
    document.getElementById("P_heading").innerHTML = "EDIT PROFILE";
}


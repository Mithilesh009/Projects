//function called on clicking place order button
//function to transfer cart products to ordered products and saving in local storage
function placeOrder() {
    var cartProducts = JSON.parse(localStorage.getItem('cart'));
    var previousOrder = JSON.parse(localStorage.getItem('orders'));
    var orders = [];
    if (cartProducts != null) {
        cartProducts.map(data => orders.push(data));
    } else {
        alert("! No cart product !");
    }
    if (previousOrder != null) {
        previousOrder.map(data => orders.push(data));
    }
    localStorage.setItem('orders', JSON.stringify(orders));
    window.localStorage.removeItem('cart');
    window.open("thankyou.html");
}
let previousPaymentStep;
//on click of change button it expands that card and closes previous card & also change some styling elements
$('.paymentStepToggler').click(function () {
    $(previousPaymentStep).find('.content').hide();
    $(previousPaymentStep).find('.paymentStepToggler').toggle();
    $(previousPaymentStep).find('.hide').toggle();
    $(previousPaymentStep).closest('.paymentStep').find('.head').css("border-left", "0px");
    $(this).closest('.paymentStep').find('.content').slideDown(100);
    //changing styling of current payment card div
    $(this).closest('.paymentStep').find('.paymentStepToggler').toggle();
    $(this).closest('.paymentStep').find('.head').css("border-left", "8px solid #ff8137");
    $(this).closest('.paymentStep').find('.hide').toggle();
    previousPaymentStep = $(this).closest('.paymentStep');
});

$('.paymentStepToggler.active').click();